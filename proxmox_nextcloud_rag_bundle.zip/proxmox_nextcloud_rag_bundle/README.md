# Nextcloud RAG on Proxmox

This bundle is meant for a **separate Debian/Ubuntu LXC or VM on Proxmox**, not your existing Nextcloud app container.

## Why a separate LXC/VM is better

Running this inside the existing Nextcloud container will work in some cases, but it couples your document sync/index stack to the Nextcloud app stack. That makes upgrades, troubleshooting, backups, and restarts messier. A separate LXC/VM is cleaner:

- Nextcloud container keeps doing only Nextcloud
- this service reads from Nextcloud over WebDAV
- the index and chat service can restart independently
- you can move Ollama later without touching Nextcloud

## What this does

- syncs `/model_data` from Nextcloud over WebDAV
- stores files locally under `/opt/nextcloud-rag/data/model_data`
- rebuilds a FAISS vector index
- retrieves relevant chunks for a question
- sends retrieved context to Ollama
- exposes a simple clickable web UI on port `7860`

## Recommended architecture

### Best option
- Proxmox host
  - LXC/VM 1: Nextcloud
  - LXC/VM 2: this RAG service
  - optional LXC/VM 3: Ollama if you want inference somewhere else

### Also acceptable
- same LXC/VM for this service and Ollama

### Not recommended
- installing this directly inside the Nextcloud application container

## Quick setup

Open a shell in a fresh Debian/Ubuntu LXC or VM, then copy this bundle there.

### 1. Install

```bash
chmod +x install.sh
./install.sh
```

### 2. Configure

```bash
sudo cp /opt/nextcloud-rag/.env.example /opt/nextcloud-rag/.env
sudo nano /opt/nextcloud-rag/.env
```

Fill in:
- `NEXTCLOUD_WEBDAV_URL`
- `NEXTCLOUD_USERNAME`
- `NEXTCLOUD_APP_PASSWORD`
- `NEXTCLOUD_REMOTE_PATH=/model_data`
- `OLLAMA_URL`
- `OLLAMA_MODEL`

Use a **Nextcloud app password**, not your main password.

### 3. Install Ollama

If you want the model running on this same machine:

```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull phi3:mini
```

If you want Ollama elsewhere, keep this service here and set `OLLAMA_URL` to the other machine.

### 4. First run

```bash
source /opt/nextcloud-rag/.venv/bin/activate
python /opt/nextcloud-rag/rag_app.py sync-index
```

### 5. Ask a test question

```bash
python /opt/nextcloud-rag/rag_app.py ask "What files are in the knowledge base?"
```

### 6. Start the clickable UI

```bash
python /opt/nextcloud-rag/rag_app.py serve --host 0.0.0.0 --port 7860
```

Then open:

```text
http://YOUR-LXC-IP:7860
```

## Make it automatic with systemd

Copy the service files:

```bash
sudo cp nextcloud-rag-sync.service /etc/systemd/system/
sudo cp nextcloud-rag-sync.timer /etc/systemd/system/
sudo cp nextcloud-rag-ui.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now nextcloud-rag-sync.timer
sudo systemctl enable --now nextcloud-rag-ui.service
```

That gives you:
- automatic sync + index rebuild every 3 days
- always-on web UI on port `7860`

## Notes

- This rebuilds the full index each time. It is simpler and matches your “speed doesn’t matter much” goal.
- CPU-only inference is fine if you do not mind waiting.
- If your Proxmox machine has no GPU, this still works; Ollama will just be slower.
- Supported files by default: PDF, TXT, MD, DOCX, CSV.
- You can change file types in `.env` with `ALLOWED_SUFFIXES`.
