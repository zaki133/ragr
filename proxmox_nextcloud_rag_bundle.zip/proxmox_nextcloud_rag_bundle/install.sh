#!/usr/bin/env bash
set -euo pipefail

APP_DIR=/opt/nextcloud-rag
PYTHON_BIN=${PYTHON_BIN:-python3}

sudo mkdir -p "$APP_DIR"
sudo cp rag_app.py requirements.txt .env.example "$APP_DIR"/
cd "$APP_DIR"

sudo apt-get update
sudo apt-get install -y "$PYTHON_BIN" python3-venv python3-pip build-essential curl

$PYTHON_BIN -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo
echo "Installed into $APP_DIR"
echo "Next:"
echo "  1) cp $APP_DIR/.env.example $APP_DIR/.env"
echo "  2) edit $APP_DIR/.env"
echo "  3) install Ollama if you want local answering on this box"
echo "  4) run: source $APP_DIR/.venv/bin/activate && python $APP_DIR/rag_app.py sync-index"
echo "  5) run: source $APP_DIR/.venv/bin/activate && python $APP_DIR/rag_app.py serve"
