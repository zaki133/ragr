from __future__ import annotations

import argparse
import json
import os
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Dict, Iterable, List, Tuple
from urllib.parse import quote, urljoin

import faiss
import gradio as gr
import numpy as np
import requests
from dotenv import load_dotenv
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer

try:
    from docx import Document as DocxDocument
except Exception:  # pragma: no cover
    DocxDocument = None

NS = {"d": "DAV:"}


@dataclass
class RemoteEntry:
    path: str
    is_dir: bool
    etag: str | None
    size: int | None


DEFAULT_SYSTEM_PROMPT = (
    "You answer questions using only the provided context from the user's synced documents. "
    "If the answer is not clearly supported by the context, say you do not know. "
    "Prefer concise answers and cite source filenames when relevant."
)


class ConfigError(RuntimeError):
    pass


class AppConfig:
    def __init__(self) -> None:
        load_dotenv()
        self.nextcloud_webdav_url = self._required("NEXTCLOUD_WEBDAV_URL").rstrip("/") + "/"
        self.nextcloud_username = self._required("NEXTCLOUD_USERNAME")
        self.nextcloud_password = self._required("NEXTCLOUD_APP_PASSWORD")
        self.remote_root = self._normalize_remote_path(os.getenv("NEXTCLOUD_REMOTE_PATH", "/model_data"))
        self.local_sync_dir = Path(os.getenv("LOCAL_SYNC_DIR", "/opt/nextcloud-rag/data/model_data"))
        self.state_dir = Path(os.getenv("STATE_DIR", "/opt/nextcloud-rag/state"))
        self.index_dir = Path(os.getenv("INDEX_DIR", "/opt/nextcloud-rag/index"))
        self.embedding_model = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
        self.ollama_url = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
        self.ollama_model = os.getenv("OLLAMA_MODEL", "phi3:mini")
        self.chunk_size = int(os.getenv("CHUNK_SIZE", "1000"))
        self.chunk_overlap = int(os.getenv("CHUNK_OVERLAP", "150"))
        self.top_k = int(os.getenv("TOP_K", "4"))
        self.system_prompt = os.getenv("SYSTEM_PROMPT", DEFAULT_SYSTEM_PROMPT)
        self.allowed_suffixes = {
            s.strip().lower()
            for s in os.getenv("ALLOWED_SUFFIXES", ".pdf,.txt,.md,.docx,.csv").split(",")
            if s.strip()
        }

    @staticmethod
    def _required(name: str) -> str:
        value = os.getenv(name)
        if not value:
            raise ConfigError(f"Missing required setting: {name}")
        return value

    @staticmethod
    def _normalize_remote_path(value: str) -> str:
        value = value.strip() or "/"
        if not value.startswith("/"):
            value = "/" + value
        return value.rstrip("/") or "/"


def ensure_dirs(cfg: AppConfig) -> None:
    cfg.local_sync_dir.mkdir(parents=True, exist_ok=True)
    cfg.state_dir.mkdir(parents=True, exist_ok=True)
    cfg.index_dir.mkdir(parents=True, exist_ok=True)


def manifest_path(cfg: AppConfig) -> Path:
    return cfg.state_dir / "manifest.json"


def metadata_path(cfg: AppConfig) -> Path:
    return cfg.index_dir / "metadata.json"


def faiss_path(cfg: AppConfig) -> Path:
    return cfg.index_dir / "vectors.faiss"


def auth(cfg: AppConfig) -> Tuple[str, str]:
    return (cfg.nextcloud_username, cfg.nextcloud_password)


def remote_url(cfg: AppConfig, remote_path: str) -> str:
    rel = remote_path.lstrip("/")
    return urljoin(cfg.nextcloud_webdav_url, quote(rel))


def propfind(cfg: AppConfig, remote_path: str, depth: int = 1) -> List[RemoteEntry]:
    url = remote_url(cfg, remote_path)
    body = """<?xml version=\"1.0\"?>
<d:propfind xmlns:d=\"DAV:\">
  <d:prop>
    <d:resourcetype />
    <d:getetag />
    <d:getcontentlength />
  </d:prop>
</d:propfind>
"""
    headers = {"Depth": str(depth), "Content-Type": "application/xml"}
    resp = requests.request("PROPFIND", url, auth=auth(cfg), headers=headers, data=body, timeout=120)
    resp.raise_for_status()
    root = ET.fromstring(resp.text)
    entries: List[RemoteEntry] = []
    base_norm = str(PurePosixPath(remote_path))

    for response in root.findall("d:response", NS):
        href = response.findtext("d:href", default="", namespaces=NS)
        prop = response.find("d:propstat/d:prop", NS)
        if prop is None:
            continue
        collection = prop.find("d:resourcetype/d:collection", NS) is not None
        etag = prop.findtext("d:getetag", default=None, namespaces=NS)
        size_text = prop.findtext("d:getcontentlength", default=None, namespaces=NS)
        size = int(size_text) if size_text and size_text.isdigit() else None

        # Convert href back into a clean path relative to WebDAV root.
        path_part = href
        if cfg.nextcloud_webdav_url in href:
            path_part = href.split(cfg.nextcloud_webdav_url, 1)[1]
        else:
            # fall back to removing domain path prefix if possible
            from urllib.parse import urlparse, unquote
            path_part = unquote(urlparse(href).path)
            base_path = "/" + "/".join(urlparse(cfg.nextcloud_webdav_url).path.strip("/").split("/"))
            if path_part.startswith(base_path):
                path_part = path_part[len(base_path):]
        path_part = "/" + path_part.lstrip("/")
        path_norm = str(PurePosixPath(path_part))

        if path_norm == base_norm:
            continue
        entries.append(RemoteEntry(path=path_norm, is_dir=collection, etag=etag, size=size))
    return entries


def walk_remote_files(cfg: AppConfig, start_path: str) -> List[RemoteEntry]:
    files: List[RemoteEntry] = []
    stack = [start_path]
    while stack:
        current = stack.pop()
        for entry in propfind(cfg, current, depth=1):
            if entry.is_dir:
                stack.append(entry.path)
            else:
                if Path(entry.path).suffix.lower() in cfg.allowed_suffixes:
                    files.append(entry)
    return sorted(files, key=lambda x: x.path)


def load_manifest(cfg: AppConfig) -> Dict[str, Dict[str, str | int | None]]:
    path = manifest_path(cfg)
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def save_manifest(cfg: AppConfig, data: Dict[str, Dict[str, str | int | None]]) -> None:
    manifest_path(cfg).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def relative_local_path(cfg: AppConfig, remote_path: str) -> Path:
    rel = PurePosixPath(remote_path).relative_to(PurePosixPath(cfg.remote_root))
    return cfg.local_sync_dir / Path(str(rel))


def download_file(cfg: AppConfig, remote_path: str, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with requests.get(remote_url(cfg, remote_path), auth=auth(cfg), stream=True, timeout=300) as resp:
        resp.raise_for_status()
        with target.open("wb") as f:
            for chunk in resp.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    f.write(chunk)


def sync_nextcloud(cfg: AppConfig) -> str:
    ensure_dirs(cfg)
    manifest = load_manifest(cfg)
    files = walk_remote_files(cfg, cfg.remote_root)
    remote_paths = {entry.path for entry in files}

    downloaded = 0
    skipped = 0
    for entry in files:
        local_path = relative_local_path(cfg, entry.path)
        current = manifest.get(entry.path)
        changed = (
            current is None
            or current.get("etag") != entry.etag
            or not local_path.exists()
            or current.get("size") != entry.size
        )
        if changed:
            download_file(cfg, entry.path, local_path)
            downloaded += 1
        else:
            skipped += 1
        manifest[entry.path] = {
            "etag": entry.etag,
            "size": entry.size,
            "local_path": str(local_path),
        }

    removed = 0
    for old_path in list(manifest.keys()):
        if old_path not in remote_paths:
            local_path = Path(str(manifest[old_path].get("local_path", "")))
            if local_path.exists():
                local_path.unlink()
                removed += 1
            manifest.pop(old_path, None)

    save_manifest(cfg, manifest)
    return f"Sync complete. Downloaded/updated: {downloaded}, skipped: {skipped}, removed: {removed}."


def extract_text(path: Path) -> str:
    suffix = path.suffix.lower()
    try:
        if suffix == ".pdf":
            reader = PdfReader(str(path))
            parts = []
            for page in reader.pages:
                text = page.extract_text() or ""
                if text.strip():
                    parts.append(text)
            return "\n\n".join(parts)
        if suffix == ".docx" and DocxDocument is not None:
            doc = DocxDocument(str(path))
            return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception as exc:
        return f""


def chunk_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    text = text.replace("\r\n", "\n").strip()
    if not text:
        return []
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks: List[str] = []
    current = ""
    for para in paragraphs:
        if len(current) + len(para) + 2 <= chunk_size:
            current = f"{current}\n\n{para}".strip()
        else:
            if current:
                chunks.append(current)
            if len(para) <= chunk_size:
                current = para
            else:
                start = 0
                while start < len(para):
                    end = start + chunk_size
                    chunks.append(para[start:end])
                    start = max(end - overlap, start + 1)
                current = ""
    if current:
        chunks.append(current)

    if overlap > 0 and len(chunks) > 1:
        merged: List[str] = [chunks[0]]
        for chunk in chunks[1:]:
            tail = merged[-1][-overlap:]
            merged.append((tail + "\n" + chunk).strip())
        return merged
    return chunks


def iter_documents(cfg: AppConfig) -> Iterable[Tuple[str, str]]:
    for path in sorted(cfg.local_sync_dir.rglob("*")):
        if path.is_file() and path.suffix.lower() in cfg.allowed_suffixes:
            text = extract_text(path)
            if text.strip():
                yield str(path.relative_to(cfg.local_sync_dir)), text


def load_embedding_model(cfg: AppConfig) -> SentenceTransformer:
    return SentenceTransformer(cfg.embedding_model)


def build_index(cfg: AppConfig) -> str:
    ensure_dirs(cfg)
    model = load_embedding_model(cfg)

    chunks: List[str] = []
    metadata: List[Dict[str, str | int]] = []
    file_count = 0

    for rel_path, text in iter_documents(cfg):
        file_count += 1
        for i, chunk in enumerate(chunk_text(text, cfg.chunk_size, cfg.chunk_overlap)):
            chunks.append(chunk)
            metadata.append({"source": rel_path, "chunk": i, "text": chunk})

    if not chunks:
        raise RuntimeError("No supported documents found after sync. Nothing to index.")

    embeddings = model.encode(chunks, normalize_embeddings=True, show_progress_bar=True)
    matrix = np.asarray(embeddings, dtype=np.float32)
    index = faiss.IndexFlatIP(matrix.shape[1])
    index.add(matrix)

    faiss.write_index(index, str(faiss_path(cfg)))
    metadata_path(cfg).write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    return f"Index rebuilt. Files indexed: {file_count}, chunks: {len(chunks)}."


def load_index(cfg: AppConfig):
    if not faiss_path(cfg).exists() or not metadata_path(cfg).exists():
        raise RuntimeError("Index files not found. Run sync and rebuild first.")
    index = faiss.read_index(str(faiss_path(cfg)))
    metadata = json.loads(metadata_path(cfg).read_text(encoding="utf-8"))
    return index, metadata


def retrieve_context(cfg: AppConfig, question: str, top_k: int | None = None) -> Tuple[str, List[Dict[str, str | int | float]]]:
    top_k = top_k or cfg.top_k
    model = load_embedding_model(cfg)
    index, metadata = load_index(cfg)
    qvec = model.encode([question], normalize_embeddings=True)
    scores, idxs = index.search(np.asarray(qvec, dtype=np.float32), top_k)

    results: List[Dict[str, str | int | float]] = []
    lines: List[str] = []
    for score, idx in zip(scores[0], idxs[0]):
        if idx < 0:
            continue
        item = metadata[idx]
        result = {
            "score": float(score),
            "source": item["source"],
            "chunk": item["chunk"],
            "text": item["text"],
        }
        results.append(result)
        lines.append(f"[Source: {item['source']} | chunk {item['chunk']}]\n{item['text']}")
    return "\n\n---\n\n".join(lines), results


def ollama_chat(cfg: AppConfig, question: str, context: str) -> str:
    url = cfg.ollama_url.rstrip("/") + "/api/chat"
    payload = {
        "model": cfg.ollama_model,
        "stream": False,
        "messages": [
            {"role": "system", "content": cfg.system_prompt},
            {
                "role": "user",
                "content": (
                    "Use the following retrieved document context to answer the question.\n\n"
                    f"Context:\n{context}\n\nQuestion: {question}"
                ),
            },
        ],
    }
    resp = requests.post(url, json=payload, timeout=600)
    resp.raise_for_status()
    data = resp.json()
    return data.get("message", {}).get("content", "")


def ask(cfg: AppConfig, question: str) -> Tuple[str, str]:
    context, hits = retrieve_context(cfg, question)
    answer = ollama_chat(cfg, question, context)
    sources = "\n".join(f"- {hit['source']} (score {hit['score']:.3f})" for hit in hits)
    return answer, sources + "\n\nRetrieved context:\n\n" + context


def action_sync_and_index(cfg: AppConfig) -> str:
    sync_msg = sync_nextcloud(cfg)
    index_msg = build_index(cfg)
    return sync_msg + "\n" + index_msg


def gradio_sync() -> str:
    cfg = AppConfig()
    return sync_nextcloud(cfg)


def gradio_rebuild() -> str:
    cfg = AppConfig()
    return build_index(cfg)


def gradio_sync_rebuild() -> str:
    cfg = AppConfig()
    return action_sync_and_index(cfg)


def gradio_ask(question: str) -> Tuple[str, str]:
    cfg = AppConfig()
    answer, details = ask(cfg, question)
    return answer, details


def serve_ui(host: str = "0.0.0.0", port: int = 7860) -> None:
    with gr.Blocks(title="Nextcloud RAG") as demo:
        gr.Markdown("# Nextcloud RAG\nSync documents from Nextcloud, rebuild the index, and ask questions with Ollama.")
        with gr.Row():
            sync_btn = gr.Button("Sync Nextcloud")
            rebuild_btn = gr.Button("Rebuild Index")
            both_btn = gr.Button("Sync + Rebuild")
        status = gr.Textbox(label="Status", lines=8)
        question = gr.Textbox(label="Question")
        ask_btn = gr.Button("Ask Model")
        answer = gr.Textbox(label="Answer", lines=10)
        details = gr.Textbox(label="Sources and Retrieved Context", lines=18)

        sync_btn.click(fn=gradio_sync, outputs=status)
        rebuild_btn.click(fn=gradio_rebuild, outputs=status)
        both_btn.click(fn=gradio_sync_rebuild, outputs=status)
        ask_btn.click(fn=gradio_ask, inputs=question, outputs=[answer, details])

    demo.launch(server_name=host, server_port=port, share=False)


def main() -> None:
    parser = argparse.ArgumentParser(description="Nextcloud sync + FAISS RAG + Ollama chat")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("sync")
    sub.add_parser("index")
    sub.add_parser("sync-index")

    ask_p = sub.add_parser("ask")
    ask_p.add_argument("question")

    serve_p = sub.add_parser("serve")
    serve_p.add_argument("--host", default="0.0.0.0")
    serve_p.add_argument("--port", type=int, default=7860)

    args = parser.parse_args()
    cfg = AppConfig()
    ensure_dirs(cfg)

    if args.command == "sync":
        print(sync_nextcloud(cfg))
    elif args.command == "index":
        print(build_index(cfg))
    elif args.command == "sync-index":
        print(action_sync_and_index(cfg))
    elif args.command == "ask":
        answer, details = ask(cfg, args.question)
        print(answer)
        print("\n---\n")
        print(details)
    elif args.command == "serve":
        serve_ui(args.host, args.port)
    else:  # pragma: no cover
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
